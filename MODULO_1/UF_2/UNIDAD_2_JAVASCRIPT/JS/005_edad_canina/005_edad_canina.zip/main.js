const multiplokadorEdad=7;

let edadDelperro=parseInt(prompt('dime la edad de tu perro'))

const edadHumanadelPerro= edadDelperro * multiplokadorEdad;
document.write('si tu perro fuese humano, su edad seria '+edadHumanadelPerro + ' años');