let num1 = parseInt(prompt("Introduce un número"));

document.write(" el Primer Número introducido:" + num1);

let num2 = parseInt(prompt("Introduce el segundo número"));

document.write("<br> el Segundo Número introducido:" + num2);

let suma = num1 + num2;

document.write('<br><b><i><span style="color:red"> suma:' +suma +' <span class="span1">otra cosa');
