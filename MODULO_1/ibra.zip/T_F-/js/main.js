      // funcion para calcular la edad del usuario
    

    const formulario = document.querySelector("#form");

    const aside = document.querySelector("#barraLateral");

    formulario.onsubmit = function (e) {
        e.preventDefault()
        let nombreUsuario = document.querySelector("#nombreUsuario").value;
        let fechaNacimiento = document.querySelector("#fechaNacimiento").value;
        let estudios = document.querySelector("#estudios").value;
        // creamos un objeto date con la fecha de nacimiento
        const fechaNacimientoUsuario = new Date(fechaNacimiento);

        // obtenemos la fecha actual del sistema
        const fechaActual = new Date();

        // aseguramos que la fecha de nacimiento no sea futura
        if (fechaNacimientoUsuario > fechaActual) {
            alert("no puedes ser del futuro, amigo !");
            return;
        }

        // calculamos la diferencia de años entre las fechas
        let edad = fechaActual.getFullYear() - fechaNacimientoUsuario.getFullYear();

        // ajustamos la edad si todavia no ha sido tu cumpleaños este año
      
        const mesNacimiento = fechaNacimientoUsuario.getMonth();
        const diaNacimiento = fechaNacimientoUsuario.getDate();
        const mesActual = fechaActual.getMonth();
        const diaActual = fechaActual.getDate();

        if (mesActual < mesNacimiento || (mesActual === mesNacimiento && diaActual < diaNacimiento)) {
            edad--; // restamos un año porque todavia no cumples años
        } if (edad < 18) {
            alert('debes ser mayor de edad !');
        }
        else {
            aside.innerHTML = `
            <h2>
                Datos de registro:

            </h2>
            Nombre: ${nombreUsuario}<br>
            Fecha de Nacimiento: ${fechaNacimiento}<br>
            Estudios: ${estudios}<br>
            Edad: ${edad}<br>


                           `
        }
    }

